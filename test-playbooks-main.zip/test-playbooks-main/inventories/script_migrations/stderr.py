#!/usr/bin/env python
from __future__ import print_function
import sys

print("TEST", file=sys.stderr)
print("{}")
