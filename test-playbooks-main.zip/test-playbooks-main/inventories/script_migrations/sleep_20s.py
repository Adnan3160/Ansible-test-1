#!/usr/bin/env python
import json, time

time.sleep(20)
inventory = dict()
print(json.dumps(inventory))
