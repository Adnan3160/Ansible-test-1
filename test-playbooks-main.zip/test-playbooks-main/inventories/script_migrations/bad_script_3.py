#!/usr/bin/env python
import json

print(json.dumps({}))
