#!/usr/bin/env python
import json, time

time.sleep(300)
inventory = dict()
print(json.dumps(inventory))
