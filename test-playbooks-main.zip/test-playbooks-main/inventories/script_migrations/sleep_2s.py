#!/usr/bin/env python
import json, time

time.sleep(2)
inventory = dict()
print(json.dumps(inventory))
