ansible-playbooks
=================

A collection of basic playbooks designed to aid in testing ansible functionality.
